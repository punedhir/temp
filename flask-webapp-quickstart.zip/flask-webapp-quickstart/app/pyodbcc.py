import pyodbc
class odbc:
    def __init__(self,server,database,username,password):
        self.server=server
        self.database=database
        self.username=username
        self.password=password
        self.cnxn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+password)
        
# We will call this method to load and get the reference of the cursor for database transaction    
    def loadCursor(self,sqlstmt):
        
        cur = self.cnxn.cursor()
        cur.arraysize = 5000
        cur.execute(sqlstmt)
        return cur
    def loadCursor1(self,sqlstmt,sqlstmt1):
        print("inside cursor")
        
        cur = self.cnxn.cursor()
        cur.arraysize = 5000
        cur.execute(sqlstmt,sqlstmt1)
        return cur

    # This is an alternate method apart from above method for loading the cursor
    def getCursor(self):
        cur = self.cnxn.cursor()
        cur.arraysize = 5000
        return cur
    def doCommit(self):
        self.cnxn.commit()
    def doClose(self):
        print("inside doclose")
        self.cnxn.cursor().close()
        print("after cursor close")
        self.cnxn.close()
        print("after connection close")

        